 // algo11-4.cpp
 #define N 32767

 void main()
 {
   int a[N];
 }
